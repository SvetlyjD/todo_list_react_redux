import { createSlice } from "@reduxjs/toolkit";

export const GoodReducerGoods = createSlice({
    name: "Good",
    initialState: { goods: [] },
    reducers: {
        addGoods: (state, data) => {
            const newGoods = {
                id: Date.now(),
                title: data.payload,
                completed: false
            }
            state.goods.push(newGoods);
        },
        deleteGood: (state, data) => {
            const iddel = data.payload;
            return state.goods.filter((item) => item.id !== iddel)
        }
    }
})

export const { addGoods, deleteGood } = GoodReducerGoods.actions;
export const selectGoods = state => state.good.goods;
export default GoodReducerGoods.reducer;
