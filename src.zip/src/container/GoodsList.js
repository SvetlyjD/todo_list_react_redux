import React from "react";
import { useSelector } from "react-redux";
import { selectGoods } from "../store/taskSlice";
import Task from "../component/Task"

const GoodsList = () => {
    let tasks = useSelector(selectGoods);
    return (
        <div className="goods-field">
            {tasks.map(item => <Task title={item.title} id={item.id} ></Task>)}
        </div>
    );
}

export default GoodsList;