import React from "react";
import { useState } from "react";
import { useDispatch } from "react-redux";
import { addGoods } from "../store/taskSlice";

function CreateTask() {
    const [value, setValue] = useState("");
    const dispatch = useDispatch();
    function addToGood() {
        dispatch(addGoods(value));
    }
    return (
        <div>
            <input type="text"
                placeholder="Add Good..."
                value={value}
                onChange={(event) => setValue(event.target.value)}
            />
            <button onClick={() => addToGood()}>Create Good</button>
        </div >
    )
}

export default CreateTask;