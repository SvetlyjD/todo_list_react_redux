import CreateTask from './container/CreateTask';
import GoodsList from './container/GoodsList';

function App() {
  return (
    <div className="goods-field">
      <CreateTask></CreateTask>
      <GoodsList></GoodsList>
    </div>
  );
}

export default App;
