import { useDispatch } from "react-redux";
import { deleteGood } from "../store/taskSlice"

function Task(props) {
    const dispatch = useDispatch();
    const deleteGoodsOne = () => {
        dispatch(deleteGood(props.id));
    }
    return (
        <div className="task-block">
            <p>{props.title}</p>
            <button className="goodsDel" data-key={props.id} onClick={() => deleteGoodsOne(props.id)}>Удалить товар</button>
            <button className="goodsDone" data-key={props.id}>Выбрать</button>
        </ div>
    )
}

export default Task;